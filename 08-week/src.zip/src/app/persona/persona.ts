export class Persona {
    constructor(
      public nombre: string,
      public apellido: string,
      public documento: string,
      public fechaNacimiento: string,
      public direccion: string,
      public telefono: string,
      public correo: string
    ) {}
  }