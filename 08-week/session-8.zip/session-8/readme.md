# Creación del Componente Persona en Angular e Ionic

En este documento explicaremos cómo crear un componente en Angular e Ionic llamado `persona`. Este componente tendrá un archivo TypeScript con la clase `Persona`, un archivo HTML para la vista, un archivo CSS para los estilos y su correspondiente lógica en TypeScript.

## 1. Creación del Componente

Ejecutamos el siguiente comando en la terminal para generar el componente.

![componente](/IMG/image.png)

Esto generará una carpeta llamada `persona` dentro de `src/app/components/` con los siguientes archivos:

- `persona.component.ts`
- `persona.component.html`
- `persona.component.scss`
- `persona.component.spec.ts`

## 2. Definición de la Clase Persona en TypeScript

Editamos el archivo `persona.component.ts` para definir la clase `Persona` y agregar la lógica del componente.

![componente](/IMG/image%20copy.png)

## 3. Creación de la Vista en HTML

Editamos `persona.component.html` para definir la estructura del componente.

## 4. Estilos en CSS

Editamos `persona.component.scss` para dar estilos al componente.


## 5. Importación y Uso del Componente

Para usar el componente en otro archivo, primero lo importamos en `app.module.ts` o en el módulo correspondiente.


Y luego lo agregamos a la plantilla de otro componente o página.
![componente](/IMG/COMPONETN.PNG)

Con esto, hemos creado e integrado el componente `persona` en nuestra aplicación Angular e Ionic.
